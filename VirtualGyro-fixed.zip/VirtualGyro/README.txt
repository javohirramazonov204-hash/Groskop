VirtualGyro - qurish
1. Android Studio (JDK 17); Android 8.0+ kerak da VirtualGyro papkasini oching, Gradle sync tugashini kuting.
2. Build > Build APK(s). APK: app/build/outputs/apk/debug/
3. Telefonda: ilovani oching > ACCESSIBILITY SOZLAMALARI > Virtual Gyro ni yoqing.
4. Ilovada ON ni yoqing, o'yinni oching, kerak bo'lsa CALIBRATE bosing.
5. Yo'nalish teskari bo'lsa, X/Y teskari checkbox'larini yoqing.
