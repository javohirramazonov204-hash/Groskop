package com.example.virtualgyro

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/**
 * O'yin ustida turadigan suzuvchi boshqaruv paneli.
 * Accessibility overlay oynasi sifatida chiqadi, shuning uchun alohida "boshqa ilovalar ustida
 * ko'rsatish" ruxsati kerak emas. Barcha sozlamalar umumiy SharedPreferences orqali ishlaydi.
 */
class FloatingPanel(
    private val context: Context,
    private val wm: WindowManager,
    private val prefs: SharedPreferences,
    private val onDraw: (String) -> Unit,
    private val onClose: () -> Unit
) {
    private var root: LinearLayout? = null
    private var body: LinearLayout? = null
    private var onOffButton: Button? = null
    private var invXButton: Button? = null
    private var invYButton: Button? = null
    private var params: WindowManager.LayoutParams? = null

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()

    private fun smallButton(label: String, action: () -> Unit): Button = Button(context).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        minHeight = 0
        minimumHeight = 0
        setPadding(dp(8), dp(4), dp(8), dp(4))
        setOnClickListener { action() }
    }

    fun show() {
        if (root != null) return

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            minimumWidth = dp(210)
            setPadding(dp(8), dp(6), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(0xE6222733.toInt())
                cornerRadius = dp(10).toFloat()
            }
        }

        // Sarlavha qatori: suring, yig'ish, yopish
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val header = TextView(context).apply {
            text = "VIRTUAL GYRO  ⋮ suring"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(4), dp(8), dp(12), dp(8))
        }
        val bodyLayout = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val collapse = smallButton("–") {
            bodyLayout.visibility = if (bodyLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        val close = smallButton("✕") { onClose() }
        headerRow.addView(header, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        headerRow.addView(collapse)
        headerRow.addView(close)
        panel.addView(headerRow)

        // Tana
        val onOff = smallButton("") {
            prefs.edit().putBoolean("gyro_enabled", !prefs.getBoolean("gyro_enabled", false)).apply()
        }
        onOffButton = onOff
        bodyLayout.addView(onOff)

        val sensLabel = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
        }
        val startProgress = (prefs.getFloat("sensitivity", 800f) / 10f).toInt().coerceIn(1, 200) - 1
        sensLabel.text = "Sensitivity: ${(startProgress + 1) * 10}"
        val bar = SeekBar(context).apply {
            max = 199
            progress = startProgress
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    val value = (p + 1) * 10
                    sensLabel.text = "Sensitivity: $value"
                    if (fromUser) prefs.edit().putFloat("sensitivity", value.toFloat()).apply()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        bodyLayout.addView(sensLabel)
        bodyLayout.addView(bar)

        bodyLayout.addView(smallButton("CALIBRATE") {
            prefs.edit().putLong("calibration_request", System.currentTimeMillis()).apply()
        })

        val drawRow1 = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        drawRow1.addView(smallButton("⚫ TEPA") { onDraw("up") },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        drawRow1.addView(smallButton("🔴 PAST") { onDraw("down") },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bodyLayout.addView(drawRow1)
        val drawRow2 = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        drawRow2.addView(smallButton("🟡 CHAP") { onDraw("left") },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        drawRow2.addView(smallButton("🟢 O'NG") { onDraw("right") },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bodyLayout.addView(drawRow2)

        bodyLayout.addView(smallButton("Chiziqlarni o'chirish") {
            prefs.edit().remove("track_right").remove("track_left")
                .remove("track_down").remove("track_up").apply()
        })

        val invRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        val invX = smallButton("") {
            prefs.edit().putBoolean("invert_x", !prefs.getBoolean("invert_x", false)).apply()
        }
        val invY = smallButton("") {
            prefs.edit().putBoolean("invert_y", !prefs.getBoolean("invert_y", false)).apply()
        }
        invXButton = invX
        invYButton = invY
        invRow.addView(invX, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        invRow.addView(invY, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bodyLayout.addView(invRow)

        panel.addView(bodyLayout)
        body = bodyLayout

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_SPLIT_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("panel_x", dp(16))
            y = prefs.getInt("panel_y", dp(100))
        }
        params = lp

        header.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = params ?: return false
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = p.x
                        startY = p.y
                        touchX = e.rawX
                        touchY = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + (e.rawX - touchX).toInt()
                        p.y = startY + (e.rawY - touchY).toInt()
                        root?.let { wm.updateViewLayout(it, p) }
                    }
                    MotionEvent.ACTION_UP -> {
                        prefs.edit().putInt("panel_x", p.x).putInt("panel_y", p.y).apply()
                    }
                }
                return true
            }
        })

        try {
            wm.addView(panel, lp)
            root = panel
            refresh()
        } catch (e: Exception) {
            root = null
        }
    }

    fun hide() {
        val view = root ?: return
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // allaqachon olib tashlangan
        }
        root = null
        body = null
    }

    /** Chiziq chizish paytida panelni vaqtincha yashiramiz. */
    fun setSuspended(suspended: Boolean) {
        root?.visibility = if (suspended) View.GONE else View.VISIBLE
    }

    /** Tugma yozuvlarini sozlamalarga moslaymiz (ilovadan o'zgartirilgan bo'lishi mumkin). */
    fun refresh() {
        onOffButton?.text = if (prefs.getBoolean("gyro_enabled", false)) "GYRO: YOQILGAN" else "GYRO: O'CHIQ"
        invXButton?.text = if (prefs.getBoolean("invert_x", false)) "X teskari: HA" else "X teskari: YO'Q"
        invYButton?.text = if (prefs.getBoolean("invert_y", false)) "Y teskari: HA" else "Y teskari: YO'Q"
    }
}
