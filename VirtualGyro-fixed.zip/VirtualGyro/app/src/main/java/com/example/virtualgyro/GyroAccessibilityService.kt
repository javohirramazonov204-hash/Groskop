package com.example.virtualgyro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Surface
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

/** Foydalanuvchi chizgan harakat chizig'i: A nuqtadan B nuqtagacha. */
private class Track(val ax: Float, val ay: Float, val bx: Float, val by: Float) {
    val length: Float = hypot(bx - ax, by - ay)
    val ux: Float = (bx - ax) / length
    val uy: Float = (by - ay) / length
}

class GyroAccessibilityService : AccessibilityService(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var listening = false
    private val handler = Handler(Looper.getMainLooper())

    private var rotationSensor: Sensor? = null
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null

    private val gravity = FloatArray(3)
    private val magnetic = FloatArray(3)
    private var hasGravity = false
    private var hasMagnetic = false

    private val rawMatrix = FloatArray(9)
    private val screenMatrix = FloatArray(9)
    private val prevMatrix = FloatArray(9)
    private var hasPrev = false
    private var lastRotation = -1

    // To'plangan harakat (piksel): X = chap/o'ng, Y = tepa/past
    private var accX = 0f
    private var accY = 0f

    // Eski rejim (chiziqlar chizilmagan bo'lsa): bitta nuqtadan qisqa swipe'lar
    private var swiping = false

    // Yangi rejim: chizilgan chiziqlar bo'ylab uzluksiz harakat
    private var trackH: Track? = null   // gorizontal (qizil)
    private var trackV: Track? = null   // vertikal (ko'k)
    private var stroke: GestureDescription.StrokeDescription? = null
    private var strokeTrack = 0         // 0 yo'q, 1 gorizontal, 2 vertikal
    private var offset = 0f             // barmoq chiziq boshidan qancha masofada
    private var lastX = 0f
    private var lastY = 0f
    private var idleCycles = 0
    private var busy = false

    private var drawView: View? = null
    private var panel: FloatingPanel? = null

    private val windowManager: WindowManager
        get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val prefs by lazy { getSharedPreferences("gyro_settings", Context.MODE_PRIVATE) }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "gyro_enabled" -> {
                syncListening()
                panel?.refresh()
            }
            "invert_x", "invert_y" -> panel?.refresh()
            "panel_visible" -> syncPanel()
            "calibration_request" -> resetBaseline()
            "track_h", "track_v" -> refreshTracks()
            "draw_request" -> {
                val kind = prefs.getString("draw_request", "")?.substringBefore(":")
                if (kind == "h" || kind == "v") scheduleDraw(kind)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotationSensor == null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        refreshTracks()
        panel = FloatingPanel(
            this, windowManager, prefs,
            onDraw = { kind -> showDrawOverlay(kind) },
            onClose = { prefs.edit().putBoolean("panel_visible", false).apply() }
        )
        syncPanel()
        syncListening()
    }

    private fun syncPanel() {
        if (prefs.getBoolean("panel_visible", false)) panel?.show() else panel?.hide()
    }

    private fun syncListening() {
        if (!::sensorManager.isInitialized) return
        val enabled = prefs.getBoolean("gyro_enabled", false)
        if (enabled && !listening) {
            resetBaseline()
            refreshTracks()
            val rate = SensorManager.SENSOR_DELAY_GAME
            if (rotationSensor != null) {
                sensorManager.registerListener(this, rotationSensor, rate)
            } else {
                accelerometer?.let { sensorManager.registerListener(this, it, rate) }
                magnetometer?.let { sensorManager.registerListener(this, it, rate) }
            }
            listening = true
        } else if (!enabled && listening) {
            sensorManager.unregisterListener(this)
            listening = false
            // Barmoq ekranda qolib ketmasligi uchun qo'yib yuboramiz
            if (stroke != null && !busy) endStroke()
        }
    }

    private fun resetBaseline() {
        hasPrev = false
        accX = 0f
        accY = 0f
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        when (event.sensor.type) {
            Sensor.TYPE_GAME_ROTATION_VECTOR, Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rawMatrix, event.values)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                lowPass(gravity, event.values, hasGravity)
                hasGravity = true
                if (!hasMagnetic) return
                if (!SensorManager.getRotationMatrix(rawMatrix, null, gravity, magnetic)) return
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                lowPass(magnetic, event.values, hasMagnetic)
                hasMagnetic = true
                if (!hasGravity) return
                if (!SensorManager.getRotationMatrix(rawMatrix, null, gravity, magnetic)) return
            }
            else -> return
        }

        val rotation = currentRotation()
        if (rotation != lastRotation) {
            lastRotation = rotation
            refreshTracks()
        }
        val (axisX, axisY) = when (rotation) {
            Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
            Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
            Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
            else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
        }
        if (!SensorManager.remapCoordinateSystem(rawMatrix, axisX, axisY, screenMatrix)) return

        if (!hasPrev) {
            System.arraycopy(screenMatrix, 0, prevMatrix, 0, 9)
            hasPrev = true
            return
        }

        val m = relative(prevMatrix, screenMatrix)
        val thetaX = (m[7] - m[5]) / 2f   // tepaga/pastga qarash
        val thetaY = (m[2] - m[6]) / 2f   // chapga/o'ngga qarash
        System.arraycopy(screenMatrix, 0, prevMatrix, 0, 9)

        val sens = prefs.getFloat("sensitivity", 800f)
        val signX = if (prefs.getBoolean("invert_x", false)) 1f else -1f
        val signY = if (prefs.getBoolean("invert_y", false)) 1f else -1f
        accX += thetaY * sens * signX
        accY += thetaX * sens * signY

        if (trackH != null && trackV != null) step() else legacySwipe()
    }

    // ---------------- Yangi rejim: chiziq bo'ylab uzluksiz harakat ----------------

    private fun step() {
        if (busy) return
        val h = trackH ?: return
        val v = trackV ?: return
        val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()

        if (strokeTrack == 0) {
            // Yangi barmoq qo'yish: faqat touch slop'dan katta harakat bo'lganda (tap bo'lib qolmasligi uchun)
            val ax = abs(accX)
            val ay = abs(accY)
            if (maxOf(ax, ay) < slop * 1.5f) return
            strokeTrack = if (ax >= ay) 1 else 2
            val t = if (strokeTrack == 1) h else v
            offset = t.length / 2f
            lastX = t.ax + t.ux * offset
            lastY = t.ay + t.uy * offset
            idleCycles = 0
        }

        val track = if (strokeTrack == 1) h else v
        val pending = if (strokeTrack == 1) accX else accY
        val other = if (strokeTrack == 1) accY else accX

        // Ikkinchi o'q ancha ustun bo'lsa, barmoqni ko'tarib, ikkinchi chiziqqa o'tamiz
        if (stroke != null && abs(other) >= slop * 6f && abs(pending) < abs(other) / 2f) {
            endStroke()
            return
        }

        val target = (offset + pending).coerceIn(0f, track.length)
        val moved = target - offset
        val moving = abs(moved) >= 0.5f
        val consumed = if (moving) moved else 0f
        val remaining = pending - consumed
        val atEdge = abs(remaining) > 1f   // chiziq oxiriga yetdi: ko'tarib, markazdan qayta qo'yamiz

        idleCycles = if (moving) 0 else idleCycles + 1
        val finish = atEdge || idleCycles >= 8

        if (strokeTrack == 1) accX = remaining else accY = remaining

        val toX = if (moving) track.ax + track.ux * target else lastX
        val toY = if (moving) track.ay + track.uy * target else lastY
        val path = Path().apply {
            moveTo(lastX, lastY)
            if (moving) lineTo(toX, toY)
        }

        val duration = 20L
        val current = stroke
        val next = if (current == null) {
            GestureDescription.StrokeDescription(path, 0, duration, !finish)
        } else {
            current.continueStroke(path, 0, duration, !finish)
        }

        stroke = if (finish) null else next
        if (moving) offset = target
        lastX = toX
        lastY = toY

        busy = true
        val accepted = dispatchGesture(
            GestureDescription.Builder().addStroke(next).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    busy = false
                    if (finish) strokeTrack = 0
                    if (listening) step() else if (stroke != null) endStroke()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    busy = false
                    stroke = null
                    strokeTrack = 0
                }
            },
            null
        )
        if (!accepted) {
            busy = false
            stroke = null
            strokeTrack = 0
        }
    }

    private fun endStroke() {
        val s = stroke
        if (s == null) {
            strokeTrack = 0
            return
        }
        if (busy) return
        val path = Path().apply { moveTo(lastX, lastY) }
        val ended = s.continueStroke(path, 0, 1, false)
        stroke = null
        busy = true
        val accepted = dispatchGesture(
            GestureDescription.Builder().addStroke(ended).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    busy = false
                    strokeTrack = 0
                    if (listening) step()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    busy = false
                    strokeTrack = 0
                }
            },
            null
        )
        if (!accepted) {
            busy = false
            strokeTrack = 0
        }
    }

    // ---------------- Eski rejim (chiziqlar yo'q) ----------------

    private fun legacySwipe() {
        if (swiping) return
        val minDistance = ViewConfiguration.get(this).scaledTouchSlop * 2.5f
        if (sqrt(accX * accX + accY * accY) >= minDistance) {
            val mx = accX
            val my = accY
            accX = 0f
            accY = 0f
            performCameraSwipe(mx, my)
        }
    }

    private fun performCameraSwipe(moveX: Float, moveY: Float) {
        if (swiping) return
        swiping = true

        val (w, h) = screenSize()
        val startX = w * 0.75f
        val startY = h * 0.5f
        val endX = (startX + moveX).coerceIn(w * 0.5f, w * 0.95f)
        val endY = (startY + moveY).coerceIn(h * 0.1f, h * 0.9f)

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 30))
            .build()

        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    swiping = false
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    swiping = false
                }
            },
            null
        )
        if (!accepted) swiping = false
    }

    // ---------------- Chiziqlarni chizish va saqlash ----------------

    private fun loadTrack(key: String, w: Int, h: Int): Track? {
        val s = prefs.getString(key, null) ?: return null
        val p = s.split(",").mapNotNull { it.toFloatOrNull() }
        if (p.size != 5) return null
        // Chiziq boshqa yo'nalishdagi (portrait/landscape) ekranda chizilgan bo'lsa, ishlatmaymiz
        if ((p[4] == 1f) != (w > h)) return null
        val t = Track(p[0] * w, p[1] * h, p[2] * w, p[3] * h)
        return if (t.length > 50f) t else null
    }

    private fun saveTrack(kind: String, x1: Float, y1: Float, x2: Float, y2: Float, w: Int, h: Int) {
        var ax = x1
        var ay = y1
        var bx = x2
        var by = y2
        // Tartib: gorizontal chiziqda A chapda, vertikalda A tepada
        val swap = if (kind == "h") ax > bx else ay > by
        if (swap) {
            ax = x2; ay = y2; bx = x1; by = y1
        }
        val landscape = if (w > h) 1f else 0f
        val value = "${ax / w},${ay / h},${bx / w},${by / h},$landscape"
        prefs.edit().putString(if (kind == "h") "track_h" else "track_v", value).apply()
    }

    private fun refreshTracks() {
        val (w, h) = screenSize()
        trackH = loadTrack("track_h", w, h)
        trackV = loadTrack("track_v", w, h)
    }

    private fun scheduleDraw(kind: String) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ showDrawOverlay(kind) }, 8000L)
    }

    private fun showDrawOverlay(kind: String) {
        removeDrawOverlay()
        panel?.setSuspended(true)
        val (w, h) = screenSize()
        val red = Color.RED
        val blue = Color.rgb(30, 144, 255)
        val color = if (kind == "h") red else blue

        val others = mutableListOf<Pair<FloatArray, Int>>()
        val otherTrack = loadTrack(if (kind == "h") "track_v" else "track_h", w, h)
        if (otherTrack != null) {
            others.add(
                floatArrayOf(otherTrack.ax, otherTrack.ay, otherTrack.bx, otherTrack.by) to
                    (if (kind == "h") blue else red)
            )
        }

        val lines = if (kind == "h") {
            listOf("QIZIL chiziq: chap/o'ng harakat yo'li", "Xavfsiz joyda barmoq bilan chiziq torting")
        } else {
            listOf("KO'K chiziq: tepa/past harakat yo'li", "Xavfsiz joyda barmoq bilan chiziq torting")
        }

        val view = TrackDrawView(
            this, color, lines, others,
            onDone = { x1, y1, x2, y2 ->
                saveTrack(kind, x1, y1, x2, y2, w, h)
                handler.post {
                    removeDrawOverlay()
                    Toast.makeText(this, "Chiziq saqlandi", Toast.LENGTH_SHORT).show()
                }
            },
            onCancel = { handler.post { removeDrawOverlay() } }
        )

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            windowManager.addView(view, lp)
            drawView = view
        } catch (e: Exception) {
            panel?.setSuspended(false)
            Toast.makeText(this, "Chizish oynasini ochib bo'lmadi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeDrawOverlay() {
        val view = drawView ?: return
        try {
            windowManager.removeView(view)
        } catch (e: Exception) {
            // allaqachon olib tashlangan
        }
        drawView = null
        panel?.setSuspended(false)
    }

    // ---------------- Yordamchi ----------------

    private fun lowPass(target: FloatArray, input: FloatArray, initialised: Boolean) {
        val alpha = 0.15f
        for (i in 0..2) {
            target[i] = if (initialised) target[i] + alpha * (input[i] - target[i]) else input[i]
        }
    }

    /** a^T * b, 3x3 (row-major). */
    private fun relative(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(9)
        for (r in 0..2) {
            for (c in 0..2) {
                var s = 0f
                for (k in 0..2) s += a[k * 3 + r] * b[k * 3 + c]
                out[r * 3 + c] = s
            }
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun currentRotation(): Int = windowManager.defaultDisplay.rotation

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        swiping = false
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        handler.removeCallbacksAndMessages(null)
        removeDrawOverlay()
        panel?.hide()
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
        listening = false
        super.onDestroy()
    }
}
