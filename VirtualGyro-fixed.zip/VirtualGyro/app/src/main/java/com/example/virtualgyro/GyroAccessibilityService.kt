package com.example.virtualgyro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Surface
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.hypot

/** Foydalanuvchi belgilagan doira: markaz va radius (piksel). */
private class Circle(val cx: Float, val cy: Float, val r: Float)

class GyroAccessibilityService : AccessibilityService(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var listening = false
    private val handler = Handler(Looper.getMainLooper())

    private var rotationSensor: Sensor? = null
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null

    private val gravity = FloatArray(3)
    private val magnetic = FloatArray(3)
    private var hasGravity = false
    private var hasMagnetic = false

    private val rawMatrix = FloatArray(9)
    private val screenMatrix = FloatArray(9)
    private val prevMatrix = FloatArray(9)
    private var hasPrev = false
    private var lastRotation = -1

    // To'plangan harakat (piksel): X = chap/o'ng, Y = tepa/past
    private var accX = 0f
    private var accY = 0f

    // Yangi rejim: chizilgan chiziqlar bo'ylab uzluksiz harakat
    private var circle: Circle? = null
    private var stroke: GestureDescription.StrokeDescription? = null
    private var strokeTrack = 0         // 0 = barmoq ekranda emas, 1 = doira ichida harakatda
    private var offX = 0f              // barmoq doira markazidan qancha siljigan
    private var offY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var idleCycles = 0
    private var busy = false
    // Haqiqiy barmoq (joystick va h.k.) tegsa tizim bizning barmoqni bekor qiladi: darrov qayta bosmaymiz
    private var cooldownUntil = 0L

    private var drawView: View? = null
    private var panel: FloatingPanel? = null

    private val windowManager: WindowManager
        get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val prefs by lazy { getSharedPreferences("gyro_settings", Context.MODE_PRIVATE) }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "gyro_enabled" -> {
                syncListening()
                panel?.refresh()
            }
            "invert_x", "invert_y", "burst_mode" -> panel?.refresh()
            "panel_visible" -> syncPanel()
            "calibration_request" -> resetBaseline()
            "circle" -> refreshTracks()
            "draw_request" -> {
                val kind = prefs.getString("draw_request", "")?.substringBefore(":")
                if (kind == "circle") scheduleDraw(kind)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (rotationSensor == null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        }
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        refreshTracks()
        panel = FloatingPanel(
            this, windowManager, prefs,
            onDraw = { kind -> showDrawOverlay(kind) },
            onClose = { prefs.edit().putBoolean("panel_visible", false).apply() }
        )
        syncPanel()
        syncListening()
    }

    private fun syncPanel() {
        if (prefs.getBoolean("panel_visible", false)) panel?.show() else panel?.hide()
    }

    private fun syncListening() {
        if (!::sensorManager.isInitialized) return
        val enabled = prefs.getBoolean("gyro_enabled", false)
        if (enabled && !listening) {
            resetBaseline()
            refreshTracks()
            val rate = SensorManager.SENSOR_DELAY_GAME
            if (rotationSensor != null) {
                sensorManager.registerListener(this, rotationSensor, rate)
            } else {
                accelerometer?.let { sensorManager.registerListener(this, it, rate) }
                magnetometer?.let { sensorManager.registerListener(this, it, rate) }
            }
            listening = true
        } else if (!enabled && listening) {
            sensorManager.unregisterListener(this)
            listening = false
            // Barmoq ekranda qolib ketmasligi uchun qo'yib yuboramiz
            if (stroke != null && !busy) endStroke()
        }
    }

    private fun resetBaseline() {
        hasPrev = false
        accX = 0f
        accY = 0f
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        when (event.sensor.type) {
            Sensor.TYPE_GAME_ROTATION_VECTOR, Sensor.TYPE_ROTATION_VECTOR -> {
                SensorManager.getRotationMatrixFromVector(rawMatrix, event.values)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                lowPass(gravity, event.values, hasGravity)
                hasGravity = true
                if (!hasMagnetic) return
                if (!SensorManager.getRotationMatrix(rawMatrix, null, gravity, magnetic)) return
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                lowPass(magnetic, event.values, hasMagnetic)
                hasMagnetic = true
                if (!hasGravity) return
                if (!SensorManager.getRotationMatrix(rawMatrix, null, gravity, magnetic)) return
            }
            else -> return
        }

        val rotation = currentRotation()
        if (rotation != lastRotation) {
            lastRotation = rotation
            refreshTracks()
        }
        val (axisX, axisY) = when (rotation) {
            Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
            Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
            Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
            else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
        }
        if (!SensorManager.remapCoordinateSystem(rawMatrix, axisX, axisY, screenMatrix)) return

        if (!hasPrev) {
            System.arraycopy(screenMatrix, 0, prevMatrix, 0, 9)
            hasPrev = true
            return
        }

        val m = relative(prevMatrix, screenMatrix)
        val thetaX = (m[7] - m[5]) / 2f   // tepaga/pastga qarash
        val thetaY = (m[2] - m[6]) / 2f   // chapga/o'ngga qarash
        System.arraycopy(screenMatrix, 0, prevMatrix, 0, 9)

        val sens = prefs.getFloat("sensitivity", 800f)
        // Standart: barmoq telefon egilishiga TESKARI yuradi (tepaga egsangiz - pastga, chapga - o'ngga)
        val signX = if (prefs.getBoolean("invert_x", false)) -1f else 1f
        val signY = if (prefs.getBoolean("invert_y", false)) -1f else 1f
        accX += thetaY * sens * signX
        accY += thetaX * sens * signY

        // Faqat chizilgan chiziqlar bo'ylab ishlaymiz; chiziq yo'q bo'lsa ekranga umuman tegmaymiz
        step()
    }

    // ---------------- Yangi rejim: chiziq bo'ylab uzluksiz harakat ----------------

    private fun step() {
        if (busy) return
        val c = circle
        if (c == null) {
            accX = 0f
            accY = 0f
            if (stroke != null) endStroke() else strokeTrack = 0
            return
        }
        if (SystemClock.uptimeMillis() < cooldownUntil) return
        val slop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()

        if (strokeTrack == 0) {
            // Yangi barmoq qo'yish: faqat touch slop'dan katta harakat bo'lganda (tap bo'lib qolmasligi uchun)
            if (hypot(accX, accY) < slop * 1.5f) return
            strokeTrack = 1
            offX = 0f
            offY = 0f
            lastX = c.cx            // barmoq doira markazidan boshlanadi
            lastY = c.cy
            idleCycles = 0
        }

        // Istalgan yo'nalishda (360°) siljiymiz, doira chegarasidan chiqmaymiz
        var tx = offX + accX
        var ty = offY + accY
        val len = hypot(tx, ty)
        if (len > c.r) {
            tx *= c.r / len
            ty *= c.r / len
        }
        val mx = tx - offX
        val my = ty - offY
        val moveLen = hypot(mx, my)
        val moving = moveLen >= 0.5f
        val remX = accX - (if (moving) mx else 0f)
        val remY = accY - (if (moving) my else 0f)
        val overflow = hypot(remX, remY) > 1f   // chegaraga yetdi: ko'tarib, markazdan qayta qo'yamiz

        idleCycles = if (moving) 0 else idleCycles + 1
        if (!moving && !overflow) {
            // Harakat yo'q: bo'sh bo'lak yubormaymiz, biroz kutib barmoqni ko'taramiz
            if (idleCycles >= 8) {
                if (stroke != null) endStroke() else strokeTrack = 0
            }
            return
        }
        // QISQA rejim: har zarba alohida, tugagach barmoq ekrandan ketadi (haqiqiy barmoqlarga kam xalaqit)
        val burst = prefs.getBoolean("burst_mode", true)
        val finish = overflow || burst

        accX = remX
        accY = remY

        val toX = if (moving) c.cx + tx else lastX
        val toY = if (moving) c.cy + ty else lastY
        val path = Path().apply {
            moveTo(lastX, lastY)
            if (moving) lineTo(toX, toY)
        }

        val duration = if (burst) (moveLen / 3f).toLong().coerceIn(25L, 120L) else 20L
        val current = stroke
        val next = if (current == null) {
            GestureDescription.StrokeDescription(path, 0, duration, !finish)
        } else {
            current.continueStroke(path, 0, duration, !finish)
        }

        stroke = if (finish) null else next
        if (moving) {
            offX = tx
            offY = ty
        }
        lastX = toX
        lastY = toY

        busy = true
        val accepted = dispatchGesture(
            GestureDescription.Builder().addStroke(next).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    busy = false
                    if (finish) strokeTrack = 0
                    if (burst) cooldownUntil = SystemClock.uptimeMillis() + 40L   // zarbalar orasida tanaffus
                    if (listening) step() else if (stroke != null) endStroke()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    busy = false
                    stroke = null
                    strokeTrack = 0
                    cooldownUntil = SystemClock.uptimeMillis() + 150L
                }
            },
            null
        )
        if (!accepted) {
            busy = false
            stroke = null
            strokeTrack = 0
        }
    }

    private fun endStroke() {
        val s = stroke
        if (s == null) {
            strokeTrack = 0
            return
        }
        if (busy) return
        val path = Path().apply { moveTo(lastX, lastY) }
        val ended = s.continueStroke(path, 0, 1, false)
        stroke = null
        busy = true
        val accepted = dispatchGesture(
            GestureDescription.Builder().addStroke(ended).build(),
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    busy = false
                    strokeTrack = 0
                    if (listening) step()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    busy = false
                    strokeTrack = 0
                    cooldownUntil = SystemClock.uptimeMillis() + 150L
                }
            },
            null
        )
        if (!accepted) {
            busy = false
            strokeTrack = 0
        }
    }

    // ---------------- Chiziqlarni chizish va saqlash ----------------

    private fun loadCircle(w: Int, h: Int): Circle? {
        val str = prefs.getString("circle", null) ?: return null
        val p = str.split(",").mapNotNull { it.toFloatOrNull() }
        if (p.size != 4) return null
        // Doira boshqa yo'nalishdagi (portrait/landscape) ekranda chizilgan bo'lsa, ishlatmaymiz
        if ((p[3] == 1f) != (w > h)) return null
        val r = p[2] * minOf(w, h)
        return if (r > 30f) Circle(p[0] * w, p[1] * h, r) else null
    }

    private fun saveCircle(cx: Float, cy: Float, r: Float, w: Int, h: Int) {
        val landscape = if (w > h) 1f else 0f
        val value = "${cx / w},${cy / h},${r / minOf(w, h)},$landscape"
        prefs.edit().putString("circle", value).apply()
    }

    private fun refreshTracks() {
        val (w, h) = screenSize()
        circle = loadCircle(w, h)
    }

    private fun scheduleDraw(kind: String) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ showDrawOverlay(kind) }, 8000L)
    }

    private fun showDrawOverlay(kind: String) {
        removeDrawOverlay()
        panel?.setSuspended(true)
        val (w, h) = screenSize()
        val color = Color.rgb(0, 190, 0)

        val others = mutableListOf<Pair<FloatArray, Int>>()
        loadCircle(w, h)?.let { others.add(floatArrayOf(it.cx, it.cy, it.r) to Color.GRAY) }

        val lines = listOf(
            "DOIRA joystik: barmoq 360° harakat qiladi",
            "Markazga bosib, chetiga qarab torting (radius = masofa)"
        )

        val view = TrackDrawView(
            this, color, lines, others,
            onDone = { x1, y1, x2, y2 ->
                saveCircle(x1, y1, hypot(x2 - x1, y2 - y1), w, h)
                handler.post {
                    removeDrawOverlay()
                    Toast.makeText(this, "Chiziq saqlandi", Toast.LENGTH_SHORT).show()
                }
            },
            onCancel = { handler.post { removeDrawOverlay() } }
        )

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_SPLIT_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try {
            windowManager.addView(view, lp)
            drawView = view
        } catch (e: Exception) {
            panel?.setSuspended(false)
            Toast.makeText(this, "Chizish oynasini ochib bo'lmadi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeDrawOverlay() {
        val view = drawView ?: return
        try {
            windowManager.removeView(view)
        } catch (e: Exception) {
            // allaqachon olib tashlangan
        }
        drawView = null
        panel?.setSuspended(false)
    }

    // ---------------- Yordamchi ----------------

    private fun lowPass(target: FloatArray, input: FloatArray, initialised: Boolean) {
        val alpha = 0.15f
        for (i in 0..2) {
            target[i] = if (initialised) target[i] + alpha * (input[i] - target[i]) else input[i]
        }
    }

    /** a^T * b, 3x3 (row-major). */
    private fun relative(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(9)
        for (r in 0..2) {
            for (c in 0..2) {
                var s = 0f
                for (k in 0..2) s += a[k * 3 + r] * b[k * 3 + c]
                out[r * 3 + c] = s
            }
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun currentRotation(): Int = windowManager.defaultDisplay.rotation

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        busy = false
        stroke = null
        strokeTrack = 0
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        handler.removeCallbacksAndMessages(null)
        removeDrawOverlay()
        panel?.hide()
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
        listening = false
        super.onDestroy()
    }
}
