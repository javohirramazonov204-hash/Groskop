package com.example.virtualgyro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * To'liq ekran chizish paneli. Foydalanuvchi barmog'i bilan chiziq tortadi,
 * chiziqning boshi va oxiri (ekran koordinatalarida) onDone orqali qaytariladi.
 */
class TrackDrawView(
    context: Context,
    private val color: Int,
    private val lines: List<String>,
    private val others: List<Pair<FloatArray, Int>>,
    private val onDone: (Float, Float, Float, Float) -> Unit,
    private val onCancel: () -> Unit
) : View(context) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 12f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = 0xFFFFFFFF.toInt()
        textSize = 40f
    }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = 0xFF444444.toInt()
    }
    private val cancelRect = RectF()

    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var hasLine = false

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cancelRect.set(w - 380f, 40f, w - 40f, 140f)
    }

    /** Oq fon ustiga rangli chiziq va strelka uchi (qora chiziq ham ko'rinsin). */
    private fun drawArrow(canvas: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, c: Int, alpha: Int) {
        val ang = atan2(y2 - y1, x2 - x1)
        val head = 50f
        val spread = 0.5f
        val hx1 = x2 - head * cos(ang - spread)
        val hy1 = y2 - head * sin(ang - spread)
        val hx2 = x2 - head * cos(ang + spread)
        val hy2 = y2 - head * sin(ang + spread)
        linePaint.strokeWidth = 20f
        linePaint.color = 0xFFFFFFFF.toInt()
        linePaint.alpha = alpha
        canvas.drawLine(x1, y1, x2, y2, linePaint)
        canvas.drawLine(x2, y2, hx1, hy1, linePaint)
        canvas.drawLine(x2, y2, hx2, hy2, linePaint)
        linePaint.strokeWidth = 12f
        linePaint.color = c
        linePaint.alpha = alpha
        canvas.drawLine(x1, y1, x2, y2, linePaint)
        canvas.drawLine(x2, y2, hx1, hy1, linePaint)
        canvas.drawLine(x2, y2, hx2, hy2, linePaint)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0x66000000)

        // Chiziqlar ekran koordinatalarida saqlanadi, shuning uchun ko'rinish siljishini hisobga olamiz
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        canvas.save()
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
        for ((p, c) in others) {
            drawArrow(canvas, p[0], p[1], p[2], p[3], c, 140)
        }
        if (hasLine) {
            drawArrow(canvas, sx, sy, ex, ey, color, 255)
        }
        canvas.restore()

        var y = 230f
        for (line in lines) {
            canvas.drawText(line, 40f, y, textPaint)
            y += 56f
        }
        canvas.drawRoundRect(cancelRect, 20f, 20f, boxPaint)
        canvas.drawText("BEKOR QILISH", cancelRect.left + 28f, cancelRect.top + 64f, textPaint)
    }

    // Faqat chiziq boshlagan barmoq hisobga olinadi; qolgan (7 tagacha) barmoqlar xalaqit bermaydi
    private var activeId = -1

    /** Berilgan barmoqning ekran koordinatasi (rawX faqat 0-barmoq uchun, shuning uchun siljishni qo'shamiz). */
    private fun rawOf(e: MotionEvent, index: Int): Pair<Float, Float> {
        val offX = e.rawX - e.getX(0)
        val offY = e.rawY - e.getY(0)
        return (e.getX(index) + offX) to (e.getY(index) + offY)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (cancelRect.contains(e.x, e.y)) {
                    onCancel()
                    return true
                }
                activeId = e.getPointerId(0)
                val (x, y) = rawOf(e, 0)
                sx = x; sy = y; ex = x; ey = y
                hasLine = true
            }
            MotionEvent.ACTION_MOVE -> {
                val i = e.findPointerIndex(activeId)
                if (i >= 0 && hasLine) {
                    val (x, y) = rawOf(e, i)
                    ex = x; ey = y
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // Chiziq barmog'i ko'tarilsa - tugatamiz, boshqa barmoqlar e'tiborga olinmaydi
                val i = e.findPointerIndex(activeId)
                if (i >= 0 && i == e.actionIndex && hasLine) finishLine(e, i)
            }
            MotionEvent.ACTION_UP -> {
                val i = e.findPointerIndex(activeId)
                if (i >= 0 && hasLine) finishLine(e, i) else hasLine = false
                activeId = -1
            }
            MotionEvent.ACTION_CANCEL -> {
                hasLine = false
                activeId = -1
            }
        }
        invalidate()
        return true
    }

    private fun finishLine(e: MotionEvent, index: Int) {
        val (x, y) = rawOf(e, index)
        ex = x
        ey = y
        activeId = -1
        if (hypot(ex - sx, ey - sy) >= 120f) onDone(sx, sy, ex, ey) else hasLine = false
    }
}
