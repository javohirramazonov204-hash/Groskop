package com.example.virtualgyro

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * To'liq ekran chizish paneli. Foydalanuvchi barmog'i bilan chiziq tortadi,
 * chiziqning boshi va oxiri (ekran koordinatalarida) onDone orqali qaytariladi.
 */
class TrackDrawView(
    context: Context,
    private val color: Int,
    private val lines: List<String>,
    private val others: List<Pair<FloatArray, Int>>,
    private val onDone: (Float, Float, Float, Float) -> Unit,
    private val onCancel: () -> Unit
) : View(context) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 12f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = 0xFFFFFFFF.toInt()
        textSize = 40f
    }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = 0xFF444444.toInt()
    }
    private val cancelRect = RectF()

    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var hasLine = false

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cancelRect.set(w - 380f, 40f, w - 40f, 140f)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0x66000000)

        // Chiziqlar ekran koordinatalarida saqlanadi, shuning uchun ko'rinish siljishini hisobga olamiz
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        canvas.save()
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
        for ((p, c) in others) {
            linePaint.color = c
            linePaint.alpha = 120
            canvas.drawLine(p[0], p[1], p[2], p[3], linePaint)
        }
        if (hasLine) {
            linePaint.color = color
            linePaint.alpha = 255
            canvas.drawLine(sx, sy, ex, ey, linePaint)
        }
        canvas.restore()

        var y = 230f
        for (line in lines) {
            canvas.drawText(line, 40f, y, textPaint)
            y += 56f
        }
        canvas.drawRoundRect(cancelRect, 20f, 20f, boxPaint)
        canvas.drawText("BEKOR QILISH", cancelRect.left + 28f, cancelRect.top + 64f, textPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (cancelRect.contains(e.x, e.y)) {
                    onCancel()
                    return true
                }
                sx = e.rawX
                sy = e.rawY
                ex = sx
                ey = sy
                hasLine = true
            }
            MotionEvent.ACTION_MOVE -> {
                ex = e.rawX
                ey = e.rawY
            }
            MotionEvent.ACTION_UP -> {
                ex = e.rawX
                ey = e.rawY
                if (hasLine && hypot(ex - sx, ey - sy) >= 120f) {
                    onDone(sx, sy, ex, ey)
                } else {
                    hasLine = false
                }
            }
            MotionEvent.ACTION_CANCEL -> hasLine = false
        }
        invalidate()
        return true
    }
}
