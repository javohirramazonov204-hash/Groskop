package com.example.virtualgyro

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Toast
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("gyro_settings", MODE_PRIVATE)
    }

    private lateinit var sensitivityLabel: TextView
    private var gyroSwitch: Switch? = null
    private var invertXBox: CheckBox? = null
    private var invertYBox: CheckBox? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }

        layout.addView(TextView(this).apply {
            text = "VIRTUAL GYRO"
            textSize = 26f
        })

        layout.addView(TextView(this).apply {
            text = "Ekran boshqaruvi sozlamalari"
            textSize = 16f
        })

        gyroSwitch = Switch(this).apply {
            text = "Virtual Gyro ON / OFF"
            textSize = 17f
            isChecked = prefs.getBoolean("gyro_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("gyro_enabled", checked).apply()
            }
        }
        layout.addView(gyroSwitch!!)

        sensitivityLabel = TextView(this).apply {
            textSize = 17f
            setPadding(0, 28, 0, 8)
        }

        val sensitivityBar = SeekBar(this).apply {
            max = 199
            progress = (prefs.getFloat("sensitivity", 800f) / 10f)
                .toInt().coerceIn(1, 200) - 1
            updateSensitivityLabel(progress + 1)

            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val value = ((progress + 1) * 10).toFloat()
                    updateSensitivityLabel(progress + 1)
                    prefs.edit().putFloat("sensitivity", value).apply()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        layout.addView(sensitivityLabel)
        layout.addView(sensitivityBar)

        invertXBox = CheckBox(this).apply {
            text = "X o'qini teskari qilish (chap/o'ng)"
            isChecked = prefs.getBoolean("invert_x", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("invert_x", checked).apply()
            }
        }
        layout.addView(invertXBox!!)

        invertYBox = CheckBox(this).apply {
            text = "Y o'qini teskari qilish (tepa/past)"
            isChecked = prefs.getBoolean("invert_y", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("invert_y", checked).apply()
            }
        }
        layout.addView(invertYBox!!)

        layout.addView(Button(this).apply {
            text = "SUZUVCHI PANELNI KO'RSATISH"
            setOnClickListener {
                prefs.edit().putBoolean("panel_visible", true).apply()
                Toast.makeText(
                    this@MainActivity,
                    "Panel o'yin ustida chiqadi (Accessibility servisi yoqilgan bo'lishi kerak)",
                    Toast.LENGTH_LONG
                ).show()
            }
        })

        layout.addView(Button(this).apply {
            text = "Suzuvchi panelni yashirish"
            setOnClickListener {
                prefs.edit().putBoolean("panel_visible", false).apply()
            }
        })

        layout.addView(Button(this).apply {
            text = "CALIBRATE"
            setOnClickListener {
                prefs.edit()
                    .putLong("calibration_request", System.currentTimeMillis())
                    .apply()
            }
        })

        layout.addView(Button(this).apply {
            text = "QIZIL CHIZIQ chizish (chap/o'ng)"
            setOnClickListener {
                requestDraw("h")
            }
        })

        layout.addView(Button(this).apply {
            text = "KO'K CHIZIQ chizish (tepa/past)"
            setOnClickListener {
                requestDraw("v")
            }
        })

        layout.addView(Button(this).apply {
            text = "Chiziqlarni o'chirish"
            setOnClickListener {
                prefs.edit().remove("track_h").remove("track_v").apply()
                Toast.makeText(this@MainActivity, "Chiziqlar o'chirildi", Toast.LENGTH_SHORT).show()
            }
        })

        layout.addView(Button(this).apply {
            text = "ACCESSIBILITY SOZLAMALARI"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        layout.addView(TextView(this).apply {
            text = "Suzuvchi panel o'yin ustida turadi: u yerdan ON/OFF, sezgirlik, kalibrlash va chiziq chizishni boshqarasiz. Chiziq chizish (ilovadan): tugmani bosing, 8 soniya ichida o'yinni oching, so'ng xavfsiz joyda (tugmalardan uzoqda) barmoq bilan chiziq torting. Ikkala chiziq chizilsa, gyro shu chiziqlar bo'ylab uzluksiz harakat qiladi. Chiziq chizilmasa, eski rejim ishlaydi. Servis yoqilgan bo'lishi kerak. Kalibrlashdan oldin telefonni kerakli boshlang'ich holatda ushlang."
            textSize = 14f
            setPadding(0, 20, 0, 0)
        })

        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        // Suzuvchi paneldan o'zgartirilgan qiymatlarni ko'rsatamiz
        gyroSwitch?.isChecked = prefs.getBoolean("gyro_enabled", false)
        invertXBox?.isChecked = prefs.getBoolean("invert_x", false)
        invertYBox?.isChecked = prefs.getBoolean("invert_y", false)
    }

    private fun requestDraw(kind: String) {
        prefs.edit().putString("draw_request", "$kind:${System.currentTimeMillis()}").apply()
        Toast.makeText(
            this,
            "8 soniyadan keyin chizish oynasi chiqadi. O'yinni oching!",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun updateSensitivityLabel(level: Int) {
        sensitivityLabel.text = "Sensitivity: ${level * 10}"
    }
}
