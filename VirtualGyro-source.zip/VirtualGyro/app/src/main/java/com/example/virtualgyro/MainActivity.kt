package com.example.virtualgyro

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("gyro_settings", MODE_PRIVATE)
    }

    private lateinit var sensitivityLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 32)
        }

        layout.addView(TextView(this).apply {
            text = "VIRTUAL GYRO"
            textSize = 26f
        })

        layout.addView(TextView(this).apply {
            text = "Ekran boshqaruvi sozlamalari"
            textSize = 16f
        })

        layout.addView(Switch(this).apply {
            text = "Virtual Gyro ON / OFF"
            textSize = 17f
            isChecked = prefs.getBoolean("gyro_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("gyro_enabled", checked).apply()
            }
        })

        sensitivityLabel = TextView(this).apply {
            textSize = 17f
            setPadding(0, 28, 0, 8)
        }

        val sensitivityBar = SeekBar(this).apply {
            max = 199
            progress = (prefs.getFloat("sensitivity", 800f) / 10f)
                .toInt().coerceIn(1, 200) - 1
            updateSensitivityLabel(progress + 1)

            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val value = ((progress + 1) * 10).toFloat()
                    updateSensitivityLabel(progress + 1)
                    prefs.edit().putFloat("sensitivity", value).apply()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        layout.addView(sensitivityLabel)
        layout.addView(sensitivityBar)

        layout.addView(Button(this).apply {
            text = "CALIBRATE"
            setOnClickListener {
                prefs.edit()
                    .putLong("calibration_request", System.currentTimeMillis())
                    .apply()
            }
        })

        layout.addView(Button(this).apply {
            text = "ACCESSIBILITY SOZLAMALARI"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        layout.addView(TextView(this).apply {
            text = "Kalibrlashdan oldin telefonni kerakli boshlang'ich holatda ushlang."
            textSize = 14f
            setPadding(0, 20, 0, 0)
        })

        setContentView(layout)
    }

    private fun updateSensitivityLabel(level: Int) {
        sensitivityLabel.text = "Sensitivity: ${level * 10}"
    }
}
