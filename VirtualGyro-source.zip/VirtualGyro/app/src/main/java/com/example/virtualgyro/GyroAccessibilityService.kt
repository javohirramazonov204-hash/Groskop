package com.example.virtualgyro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.PI
import kotlin.math.abs

class GyroAccessibilityService : AccessibilityService(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null

    private val gravity = FloatArray(3)
    private val magnetic = FloatArray(3)
    private val rotation = FloatArray(9)
    private val orientation = FloatArray(3)

    private var hasGravity = false
    private var hasMagnetic = false
    private var firstReading = true
    private var swiping = false

    private var lastPitch = 0f
    private var lastRoll = 0f
    private var lastCalibrationRequest = 0L

    private val deadZone = 0.015f

    private val prefs by lazy {
        getSharedPreferences("gyro_settings", Context.MODE_PRIVATE)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        magnetometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                System.arraycopy(event.values, 0, gravity, 0, 3)
                hasGravity = true
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                System.arraycopy(event.values, 0, magnetic, 0, 3)
                hasMagnetic = true
            }
        }

        if (!hasGravity || !hasMagnetic) return
        if (!SensorManager.getRotationMatrix(rotation, null, gravity, magnetic)) return

        SensorManager.getOrientation(rotation, orientation)
        val pitch = orientation[1]
        val roll = orientation[2]

        val calibrationRequest = prefs.getLong("calibration_request", 0L)
        if (calibrationRequest != lastCalibrationRequest) {
            lastCalibrationRequest = calibrationRequest
            lastPitch = pitch
            lastRoll = roll
            firstReading = false
            return
        }

        if (firstReading) {
            lastPitch = pitch
            lastRoll = roll
            firstReading = false
            return
        }

        val deltaX = normalizeAngle(pitch - lastPitch)
        val deltaY = normalizeAngle(roll - lastRoll)
        lastPitch = pitch
        lastRoll = roll

        if (!prefs.getBoolean("gyro_enabled", false)) return

        if (!swiping && (abs(deltaX) > deadZone || abs(deltaY) > deadZone)) {
            val sensitivity = prefs.getFloat("sensitivity", 800f)
            performCameraSwipe(deltaX * sensitivity, deltaY * sensitivity)
        }
    }

    private fun normalizeAngle(angle: Float): Float {
        var result = angle
        while (result > PI) result -= (2.0 * PI).toFloat()
        while (result < -PI) result += (2.0 * PI).toFloat()
        return result
    }

    private fun performCameraSwipe(moveX: Float, moveY: Float) {
        if (swiping) return
        swiping = true

        val metrics = resources.displayMetrics
        val startX = metrics.widthPixels * 0.75f
        val startY = metrics.heightPixels * 0.5f
        val endX = (startX + moveX).coerceIn(
            metrics.widthPixels * 0.5f,
            metrics.widthPixels * 0.95f
        )
        val endY = (startY + moveY).coerceIn(
            metrics.heightPixels * 0.1f,
            metrics.heightPixels * 0.9f
        )

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 30))
            .build()

        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    swiping = false
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    swiping = false
                }
            },
            null
        )

        if (!accepted) swiping = false
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
    }

    override fun onDestroy() {
        if (::sensorManager.isInitialized) sensorManager.unregisterListener(this)
        super.onDestroy()
    }
}
